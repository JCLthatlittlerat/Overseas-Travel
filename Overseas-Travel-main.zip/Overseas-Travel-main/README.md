# Overseas-Travel
This is a group project for Overseas travel website. We as a team are here to build the worlds best Travel web application that enable users to Book for Hotels and Transportation tickets, see the Trending tourist sites and rent a car for their trips.
